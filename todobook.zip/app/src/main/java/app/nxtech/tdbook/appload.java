package app.nxtech.tdbook;

public class appload {
    public static boolean ison=false;
}
