package app.nxtech.tdbook;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import app.nxtech.tdbook.databinding.*;
import com.scalified.fab.*;
import com.scalified.uitools.*;
import com.scalified.viewmover.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class WelActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private WelBinding binding;
	
	private Intent intent = new Intent();
	private TimerTask tm;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = WelBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
	}
	
	private void initializeLogic() {
		if (appload.ison) {
			intent.setClass(getApplicationContext(), MainActivity.class);
			startActivity(intent);
			finish();
		} else {
			tm = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							appload.ison = true;
							intent.setClass(getApplicationContext(), MainActivity.class);
							startActivity(intent);
							finish();
						}
					});
				}
			};
			_timer.schedule(tm, (int)(2000));
		}
		binding.textview9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/heh.ttf"), 1);
	}
	
}