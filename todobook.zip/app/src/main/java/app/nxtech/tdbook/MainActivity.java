package app.nxtech.tdbook;

import app.nxtech.tdbook.WelActivity;
import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import app.nxtech.tdbook.databinding.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.scalified.fab.*;
import com.scalified.uitools.*;
import com.scalified.viewmover.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private MainBinding binding;
	private HashMap<String, Object> todomap = new HashMap<>();
	private String updatedoninfo = "";
	private String updatedtimeinfo = "";
	private String completeinfo = "";
	private String github = "";
	private String Facebook = "";
	private String WhatsApp = "";
	private String email = "";
	private double searchindex = 0;
	private double historyindex = 0;
	private boolean historyavailable = false;
	private String searchtext = "";
	
	private ArrayList<HashMap<String, Object>> todolistmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> searched = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> historymap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> history = new ArrayList<>();
	
	private AlertDialog.Builder dial;
	private Calendar calender = Calendar.getInstance();
	private AlertDialog.Builder datedialog;
	private AlertDialog.Builder doned;
	private ProgressDialog pro;
	private TimerTask tm;
	private Intent intent = new Intent();
	private Notification notef;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		dial = new AlertDialog.Builder(this);
		datedialog = new AlertDialog.Builder(this);
		doned = new AlertDialog.Builder(this);
		
		binding.imageview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final AlertDialog dial = new AlertDialog.Builder(MainActivity.this).create();
				View inflate = getLayoutInflater().inflate(R.layout.aboutapp, null);
				dial.setView(inflate);
				dial.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
				final TextView textview2 = (TextView)
				inflate.findViewById(R.id.textview2);
				final TextView textview8 = (TextView)
				inflate.findViewById(R.id.textview8);
				final LinearLayout linear2 = (LinearLayout)
				inflate.findViewById(R.id.linear2);
				final ImageView imageview2 = (ImageView)
				inflate.findViewById(R.id.imageview2);
				final ImageView imageview3 = (ImageView)
				inflate.findViewById(R.id.imageview3);
				final ImageView imageview4 = (ImageView)
				inflate.findViewById(R.id.imageview4);
				dial.setCancelable(false);
				final ImageView imageview5 = (ImageView)
				inflate.findViewById(R.id.imageview5);
				textview8.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						dial.dismiss();
					}
				});
				linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
						this.setColor(b); 
						this.setStroke(c, d); 
						return this; 
					} }.getIns((int)20, 0xFFFFFFFF,1 ,0xFFFFFFFF));
				textview8.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
						this.setColor(b); 
						this.setStroke(c, d); 
						return this; 
					} }.getIns((int)5, Color.TRANSPARENT,1 ,0xFF000000));
				github = "https://github.com/mwacha3";
				Facebook = "https://facebook.com/mwachande.nyson";
				WhatsApp = "https://wa.me/message/DMUHDPJWHIKOB1";
				email = "mailto:nysonben1@gmail.com";
				dial.show();
				imageview2.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent.setAction(Intent.ACTION_VIEW);
						intent.setData(Uri.parse(github));
						startActivity(intent);
					}
				});
				imageview3.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent.setAction(Intent.ACTION_VIEW);
						intent.setData(Uri.parse(Facebook));
						startActivity(intent);
					}
				});
				imageview4.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent.setAction(Intent.ACTION_VIEW);
						intent.setData(Uri.parse(WhatsApp));
						startActivity(intent);
					}
				});
				imageview5.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent.setAction(Intent.ACTION_SENDTO);
						intent.setData(Uri.parse(email));
						intent.putExtra(intent.EXTRA_SUBJECT, "After i use your App, i want to say.. ");
						startActivity(intent);
					}
				});
				dial.setOnKeyListener(new DialogInterface.OnKeyListener() {
					@Override
					public boolean onKey(DialogInterface dial, int keyCode, KeyEvent event) {
						if (keyCode == KeyEvent.KEYCODE_BACK) {
							dial.dismiss();
							return true;
						}
						return false;
					}
				});
			}
		});
		
		binding.imageview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_help();
			}
		});
		
		binding.searchbt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				binding.todolist.setVisibility(View.GONE);
				binding.searchwindow.setVisibility(View.VISIBLE);
			}
		});
		
		binding.actionButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final AlertDialog dial = new AlertDialog.Builder(MainActivity.this).create();
				View inflate = getLayoutInflater().inflate(R.layout.create_todo_dialog, null);
				dial.setView(inflate);
				dial.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
				final LinearLayout linear2 = (LinearLayout)
				inflate.findViewById(R.id.linear2);
				final LinearLayout linear8 = (LinearLayout)
				inflate.findViewById(R.id.linear8);
				final LinearLayout linear5 = (LinearLayout)
				inflate.findViewById(R.id.linear5);
				final LinearLayout linear4 = (LinearLayout)
				inflate.findViewById(R.id.linear4);
				final TextView date = (TextView)
				inflate.findViewById(R.id.date);
				final TextView yes = (TextView)
				inflate.findViewById(R.id.yes);
				final TextView no = (TextView)
				inflate.findViewById(R.id.no);
				final EditText edit1 = new EditText(MainActivity.this);
				final EditText edit2 = new EditText(MainActivity.this);
				Date now=new Date();
				SimpleDateFormat datepicker=new SimpleDateFormat("dd/MM/yyyy");
				final String selected=datepicker.format(now);
				date.setText(selected);
				edit1.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)));
				edit2.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)));
				dial.setCancelable(false);
				((LinearLayout) linear5).addView(edit2);
				edit1.setBackgroundColor(Color.TRANSPARENT);
				edit2.setBackgroundColor(Color.TRANSPARENT);
				edit2.setHint("add some description");
				edit1.setSingleLine(true);
				edit1.setHint("type you task title");
				linear4.addView(edit1);
				linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
						this.setColor(b); 
						this.setStroke(c, d); 
						return this; 
					} }.getIns((int)25, 0xFFFFFFFF,1 ,0xFFFFFFFF));
				linear8.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
						this.setColor(b); 
						this.setStroke(c, d); 
						return this; 
					} }.getIns((int)8, Color.TRANSPARENT,1 ,0xFF9E9E9E));
				linear4.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
						this.setColor(b); 
						this.setStroke(c, d); 
						return this; 
					} }.getIns((int)8, Color.TRANSPARENT,1 ,0xFF9E9E9E));
				linear5.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
						this.setColor(b); 
						this.setStroke(c, d); 
						return this; 
					} }.getIns((int)8, Color.TRANSPARENT,1 ,0xFF9E9E9E));
				dial.setOnKeyListener(new DialogInterface.OnKeyListener() {
					@Override
					public boolean onKey(DialogInterface dial, int keyCode, KeyEvent event) {
						if (keyCode == KeyEvent.KEYCODE_BACK) {
							dial.dismiss();
							return true;
						}
						return false;
					}
				});
				dial.show();
				linear5.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						edit2.requestFocus();
						SketchwareUtil.showKeyboard(getApplicationContext());
					}
				});
				no.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						dial.dismiss();
					}
				});
				yes.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (!edit1.getText().toString().equals("")) {
							final AlertDialog datedialog = new AlertDialog.Builder(MainActivity.this).create();
							View inflate = getLayoutInflater().inflate(R.layout.load, null);
							datedialog.setView(inflate);
							datedialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
							final LinearLayout linear2 = (LinearLayout)
							inflate.findViewById(R.id.linear2);
							tm = new TimerTask() {
								@Override
								public void run() {
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											final AlertDialog doned = new AlertDialog.Builder(MainActivity.this).create();
											View inflate = getLayoutInflater().inflate(R.layout.created, null);
											doned.setView(inflate);
											doned.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
											final TextView topnote = (TextView)
											inflate.findViewById(R.id.topnote);
											final TextView button = (TextView)
											inflate.findViewById(R.id.button);
											final LinearLayout linear2 = (LinearLayout)
											inflate.findViewById(R.id.linear2);
											button.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
													this.setColor(b); 
													this.setStroke(c, d); 
													return this; 
												} }.getIns((int)8, Color.TRANSPARENT,1 ,0xFF000000));
											linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
													this.setColor(b); 
													this.setStroke(c, d); 
													return this; 
												} }.getIns((int)25, 0xFFFFFFFF,1 ,0xFFFFFFFF));
											final ImageView img = (ImageView)
											inflate.findViewById(R.id.img);
											try{
												todomap = new HashMap<>();
												todomap.put("title", edit1.getText().toString());
												todomap.put("description", edit2.getText().toString());
												todomap.put("duedate", date.getText().toString());
												todomap.put("created", selected);
												todomap.put("updatedtime", "");
												todomap.put("updatedon", "");
												todomap.put("startat", "");
												todomap.put("endat", "");
												todomap.put("complete", false);
												todolistmap.add(todomap);
												FileUtil.writeFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/db.json"), new Gson().toJson(todolistmap));
												topnote.setText("Saving completed");
												topnote.setTextColor(0xFF4CAF50);
												img.setImageResource(R.drawable.icon_done_round);
											}catch(Exception e){
												topnote.setText("Saving failed!");
												topnote.setTextColor(0xFF000000);
												img.setImageResource(R.drawable.icon_error_outline_round);
											}
											button.setOnClickListener(new View.OnClickListener() {
												@Override
												public void onClick(View _view) {
													doned.dismiss();
													_check();
													((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
													dial.dismiss();
													_listItemsload();
												}
											});
											datedialog.dismiss();
											doned.show();
										}
									});
								}
							};
							_timer.schedule(tm, (int)(2000));
							linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
									this.setColor(b); 
									this.setStroke(c, d); 
									return this; 
								} }.getIns((int)25, 0xFFFFFFFF,1 ,0xFFFFFFFF));
							datedialog.show();
						} else {
							SketchwareUtil.showMessage(getApplicationContext(), "empty");
						}
					}
				});
				linear8.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						datedialog.setTitle("Set due date");
						final DatePicker dpicker = new DatePicker(MainActivity.this);
						dpicker.setMinDate(Calendar.getInstance().getTimeInMillis());
						String dateString = date.getText().toString();
						String[] parts = dateString.split("/");
						int day = Integer.parseInt(parts[0]);
						int month = Integer.parseInt(parts[1]) -1;
						int year = Integer.parseInt(parts[2]);
						
						dpicker.updateDate(year, month, day);
						calender = Calendar.getInstance(); 
						calender.set((int) 2026,(int) 11,(int) 31); 
						dpicker.setMaxDate(calender.getTimeInMillis());
						datedialog.setView(dpicker);
						
						datedialog.setPositiveButton("Set", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								int year=dpicker. getYear();
								int month= dpicker.getMonth()+1;
								int daydate=dpicker. getDayOfMonth();
								String nowdate=String.format("%02d/%02d/%04d",daydate,month,year);
								date.setText(nowdate);
							}
						});
						datedialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						datedialog.create().show();
					}
				});
			}
		});
		
		binding.imageview8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				binding.searchwindow.setVisibility(View.GONE);
				binding.todolist.setVisibility(View.VISIBLE);
			}
		});
		
		binding.edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				searchtext = _charSeq;
				_search(_charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		binding.imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				binding.linear4.setVisibility(View.GONE);
				binding.linear1.setVisibility(View.VISIBLE);
			}
		});
		
		binding.imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		binding.imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_help();
			}
		});
	}
	
	private void initializeLogic() {
		if (FileUtil.isExistFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/db.json"))) {
			todolistmap.clear();
			todolistmap = new Gson().fromJson(FileUtil.readFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/db.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		}
		_check();
		if (FileUtil.isExistFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/history.json"))) {
			todolistmap.clear();
			historymap = new Gson().fromJson(FileUtil.readFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/history.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		}
		_listItemsload();
		_onCreated();
		binding.listview1.setAdapter(new Listview1Adapter(todolistmap));
		((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
		binding.listview3.setAdapter(new Listview3Adapter(searched));
		((BaseAdapter)binding.listview3.getAdapter()).notifyDataSetChanged();
		binding.listview2.setAdapter(new Listview2Adapter(history));
		((BaseAdapter)binding.listview2.getAdapter()).notifyDataSetChanged();
		binding.listview1.setHorizontalScrollBarEnabled(false);
		binding.listview1.setVerticalScrollBarEnabled(false);
		binding.listview1.setOverScrollMode(ListView.OVER_SCROLL_NEVER);
		
		ActionButton actionButton = (ActionButton) findViewById(R.id.action_button);
		actionButton.removeShadow();
		actionButton.setButtonColor(0xFFF44336);//getResources().getColor(R.color.fab_material_lime_500));
		actionButton.setImageResource(R.drawable.fab_plus_icon);
		binding.imageview9.setVisibility(View.GONE);
	}
	
	@Override
	public void onBackPressed() {
		if (binding.linear4.getVisibility() == View.VISIBLE) {
			binding.linear1.setVisibility(View.VISIBLE);
			binding.linear4.setVisibility(View.GONE);
		} else {
			if (binding.searchwindow.getVisibility() == View.VISIBLE) {
				binding.todolist.setVisibility(View.VISIBLE);
				binding.searchwindow.setVisibility(View.GONE);
			} else {
				appload.ison = false;
				finish();
			}
		}
	}
	public void _onCreated() {
		binding.topbar.setBackgroundColor(0xFF000000);
		binding.linear4.setVisibility(View.GONE);
		binding.searchwindow.setVisibility(View.GONE);
		binding.noresults.setVisibility(View.GONE);
		binding.searchbt.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)8, (int)1, 0xFF9E9E9E, Color.TRANSPARENT));
		binding.reminderbt.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)8, (int)1, 0xFF1B5E20, 0xFF1B5E20));
		binding.linear7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)12, (int)1, 0xFFFFFFFF, 0xFFFFFFFF));
		binding.taskinfo.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)12, (int)1, 0xFF5D4037, 0xFF5D4037));
		binding.linear5.setBackgroundColor(0xFF000000);
		binding.linear4.setBackgroundColor(0xFFEEEEEE);
		binding.reminderbt.setVisibility(View.GONE);
		binding.reminderinfo.setVisibility(View.GONE);
		binding.textview6.setVisibility(View.GONE);
	}
	
	
	public void _listItemsload() {
		if (todolistmap.size() > 0) {
			binding.no.setVisibility(View.GONE);
			binding.listview1.setVisibility(View.VISIBLE);
			binding.count.setText("Available Tasks (".concat(String.valueOf((long)(todolistmap.size())).concat(") ")));
		} else {
			binding.no.setVisibility(View.VISIBLE);
			binding.listview1.setVisibility(View.GONE);
			binding.count.setText("no data");
		}
	}
	
	
	public void _updatelist() {
		((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
	}
	
	
	public void _viewThis(final double _pos) {
		binding.linear1.setVisibility(View.GONE);
		binding.linear4.setVisibility(View.VISIBLE);
		binding.imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_deletetask(_pos);
			}
		});
		binding.headline.setText(todolistmap.get((int)_pos).get("title").toString());
		if (!todolistmap.get((int)_pos).get("description").toString().equals("")) {
			binding.contents.setText(todolistmap.get((int)_pos).get("description").toString());
			binding.contents.setTextColor(0xFF000000);
			binding.contents.setGravity(Gravity.LEFT);
			if (binding.contents.getLineCount()>9) {
				binding.contents.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)));
			} else {
				binding.contents.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (200)));
			}
		} else {
			binding.contents.setText("no description available ");
			binding.contents.setTextColor(0xFF9E9E9E);
			binding.contents.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (200)));
			binding.contents.setGravity(Gravity.CENTER);
		}
		if (!todolistmap.get((int)_pos).get("updatedtime").toString().equals("")) {
			updatedoninfo = "Last updated time: ".concat(todolistmap.get((int)_pos).get("updatedon").toString());
			updatedtimeinfo = "Last updated: ".concat(todolistmap.get((int)_pos).get("updatedtime").toString());
		} else {
			updatedoninfo = "";
			updatedtimeinfo = "";
		}
		binding.taskinfo.setText("Task Details:\nTask created on: ".concat(todolistmap.get((int)_pos).get("created").toString().concat("\nTask Due : ".concat(todolistmap.get((int)_pos).get("duedate").toString().concat("\n".concat(updatedoninfo.concat("\n".concat(updatedtimeinfo))))))));
		if (!todolistmap.get((int)_pos).get("startat").toString().equals("")) {
			binding.reminderinfo.setText("From ".concat(todolistmap.get((int)_pos).get("startat").toString().concat(" To ".concat(todolistmap.get((int)_pos).get("endat").toString()))));
			binding.reminderinfo.setTextColor(0xFF3F51B5);
		} else {
			binding.reminderinfo.setText("no reminder available");
			binding.reminderinfo.setTextColor(0xFF9E9E9E);
		}
		if (!binding.reminderinfo.getText().toString().equals("no reminder available")) {
			binding.reminderbt.setText("Change reminder time");
		} else {
			binding.reminderbt.setText("Set reminder time");
		}
		binding.headline.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				dial.setTitle("Change headline");
				dial.setMessage("*note:\nYou can not undo while you clicked Change button! ");
				final EditText edit1 = new EditText(MainActivity.this);
				edit1.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)));
				edit1.setText(binding.headline.getText().toString());
				dial.setView(edit1);
				dial.setNegativeButton("Cancel ", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dial.setPositiveButton("Change", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (!edit1.getText().toString().equals("")) {
							if (!edit1.getText().toString().equals(todolistmap.get((int)_pos).get("title").toString())) {
								pro = new ProgressDialog(MainActivity.this);
								Date now=new Date();
								SimpleDateFormat datepicker=new SimpleDateFormat("dd/MM/yyyy");
								SimpleDateFormat timepicker=new SimpleDateFormat("HH:mm");
								final String updateddate=datepicker.format(now);
								final String updatedtime=timepicker.format(now);
								todolistmap.get((int)_pos).put("title", edit1.getText().toString());
								todolistmap.get((int)_pos).put("updatedon", updateddate);
								todolistmap.get((int)_pos).put("updatedtime", updatedtime);
								FileUtil.writeFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/db.json"), new Gson().toJson(todolistmap));
								tm = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												pro.dismiss();
												_viewThis(_pos);
											}
										});
									}
								};
								_timer.schedule(tm, (int)(1000));
								pro.setMessage("updating... ");
								pro.setCancelable(false);
								pro.show();
							} else {
								SketchwareUtil.showMessage(getApplicationContext(), "Same");
							}
						} else {
							SketchwareUtil.showMessage(getApplicationContext(), "empty");
						}
					}
				});
				dial.create().show();
				return true;
			}
		});
		binding.reminderbt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final AlertDialog datedialog = new AlertDialog.Builder(MainActivity.this).create();
				View inflate = getLayoutInflater().inflate(R.layout.settime, null);
				datedialog.setView(inflate);
				datedialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
				final TextView starttm = (TextView)
				inflate.findViewById(R.id.starttm);
				final TextView endat = (TextView)
				inflate.findViewById(R.id.endat);
				final TextView no = (TextView)
				inflate.findViewById(R.id.no);
				starttm.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
						this.setColor(b); 
						this.setStroke(c, d); 
						return this; 
					} }.getIns((int)5, 0xFFA1887F,1 ,0xFFA1887F));
				endat.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
						this.setColor(b); 
						this.setStroke(c, d); 
						return this; 
					} }.getIns((int)5, 0xFFA1887F,1 ,0xFFA1887F));
				if (!todolistmap.get((int)_pos).get("startat").toString().equals("")) {
					starttm.setText(todolistmap.get((int)_pos).get("startat").toString());
					endat.setText(todolistmap.get((int)_pos).get("endat").toString());
				} else {
					Date now=new Date();
					SimpleDateFormat datepicker=new SimpleDateFormat("dd/MM/yyyy");
					SimpleDateFormat timepicker=new SimpleDateFormat("HH:mm");
					final String updateddate=datepicker.format(now);
					final String updatedtime=timepicker.format(now);
					starttm.setText(updatedtime);
					String[] upd=updatedtime.split(":");
					int hh=Integer.parseInt(upd[0]);
					int mM=Integer.parseInt(upd[1]);
					if((mM + 5)>=60){
						if(hh==23){
							hh=00;
							mM=00;
						}else{
							hh=hh+1;
							mM=00;
						}
					}else{
						mM=mM+5;
					}
					final String updatedendtime=String.format("%02d:%02d",hh,mM);
					endat.setText(updatedendtime);
				}
				no.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						datedialog.dismiss();
					}
				});
				starttm.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						dial.setTitle("Set start time");
						final TimePicker tpicker = new TimePicker(MainActivity.this);
						String displaytime=starttm.getText().toString();
						String[] dt=displaytime.split(":");
						int hour =Integer.parseInt(dt[0]);
						int minutes =Integer.parseInt(dt[1]);
						tpicker.setIs24HourView(true);
						tpicker.setHour((int)hour);
						tpicker.setMinute((int)minutes);
						dial.setView(tpicker);
						dial.setNegativeButton("Cancel ", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						dial.setPositiveButton("set", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								int hours =tpicker.getHour();
								int minute =tpicker.getMinute();
								String tme=String.format("%02d:%02d",hours, minute);
								starttm.setText(tme);
							}
						});
					}
				});
				endat.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						dial.setTitle("Set end time");
						final TimePicker tpicker = new TimePicker(MainActivity.this);
						String displaytime=endat.getText().toString();
						String[] dt=displaytime.split(":");
						int hour =Integer.parseInt(dt[0]);
						int minutes =Integer.parseInt(dt[1]);
						tpicker.setIs24HourView(true);
						tpicker.setHour((int)hour);
						tpicker.setMinute((int)minutes);
						dial.setView(tpicker);
						dial.setNegativeButton("Cancel ", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						dial.setPositiveButton("set", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								int hours =tpicker.getHour();
								int minute =tpicker.getMinute();
								String tme=String.format("%02d:%02d",hours, minute);
								endat.setText(tme);
							}
						});
						dial.create().show();
					}
				});
				final TextView yes = (TextView)
				inflate.findViewById(R.id.yes);
				yes.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						String[] stm=starttm.getText().toString().split(":");
						int hh=Integer.parseInt(stm[0]);
						int mM=Integer.parseInt(stm[1]);
						String[] upd=endat.getText().toString().split(":");
						int hhh=Integer.parseInt(upd[0]);
						int mmM=Integer.parseInt(upd[1]);
						if((hh == hhh && mmM > mM) || (hhh > hh)){
							todolistmap.get((int)_pos).put("startat", starttm.getText().toString());
							todolistmap.get((int)_pos).put("endat", endat.getText().toString());
							FileUtil.writeFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/db.json"), new Gson().toJson(todolistmap));
							_viewThis(_pos);
							datedialog.dismiss();
						}else{
							SketchwareUtil.showMessage(getApplicationContext(), "End Time is less than start time! ");
						}
					}
				});
				datedialog.show();
			}
		});
		binding.editbt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final AlertDialog dial = new AlertDialog.Builder(MainActivity.this).create();
				View inflate = getLayoutInflater().inflate(R.layout.create_todo_dialog, null);
				dial.setView(inflate);
				dial.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
				final LinearLayout linear2 = (LinearLayout)
				inflate.findViewById(R.id.linear2);
				final LinearLayout linear8 = (LinearLayout)
				inflate.findViewById(R.id.linear8);
				final LinearLayout linear5 = (LinearLayout)
				inflate.findViewById(R.id.linear5);
				final LinearLayout linear4 = (LinearLayout)
				inflate.findViewById(R.id.linear4);
				final TextView date = (TextView)
				inflate.findViewById(R.id.date);
				final TextView yes = (TextView)
				inflate.findViewById(R.id.yes);
				final TextView no = (TextView)
				inflate.findViewById(R.id.no);
				final TextView textview1 = (TextView)
				inflate.findViewById(R.id.textview1);
				final EditText edit1 = new EditText(MainActivity.this);
				final EditText edit2 = new EditText(MainActivity.this);
				Date now=new Date();
				SimpleDateFormat datepicker=new SimpleDateFormat("dd/MM/yyyy");
				final String selected=datepicker.format(now);
				date.setText(todolistmap.get((int)_pos).get("duedate").toString());
				textview1.setText("Edit Task");
				edit1.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)));
				edit2.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)));
				dial.setCancelable(false);
				((LinearLayout) linear5).addView(edit2);
				edit1.setBackgroundColor(Color.TRANSPARENT);
				edit2.setBackgroundColor(Color.TRANSPARENT);
				edit2.setHint("add some description");
				edit1.setSingleLine(true);
				edit1.setHint("type you task title");
				edit1.setText(binding.headline.getText().toString());
				edit2.setText(todolistmap.get((int)_pos).get("description").toString());
				yes.setText("Update" );
				linear4.addView(edit1);
				linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
						this.setColor(b); 
						this.setStroke(c, d); 
						return this; 
					} }.getIns((int)25, 0xFFFFFFFF,1 ,0xFFFFFFFF));
				linear8.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
						this.setColor(b); 
						this.setStroke(c, d); 
						return this; 
					} }.getIns((int)8, Color.TRANSPARENT,1 ,0xFF9E9E9E));
				linear4.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
						this.setColor(b); 
						this.setStroke(c, d); 
						return this; 
					} }.getIns((int)8, Color.TRANSPARENT,1 ,0xFF9E9E9E));
				linear5.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
						this.setColor(b); 
						this.setStroke(c, d); 
						return this; 
					} }.getIns((int)8, Color.TRANSPARENT,1 ,0xFF9E9E9E));
				dial.setOnKeyListener(new DialogInterface.OnKeyListener() {
					@Override
					public boolean onKey(DialogInterface dial, int keyCode, KeyEvent event) {
						if (keyCode == KeyEvent.KEYCODE_BACK) {
							dial.dismiss();
							return true;
						}
						return false;
					}
				});
				dial.show();
				linear5.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						edit2.requestFocus();
						SketchwareUtil.showKeyboard(getApplicationContext());
					}
				});
				no.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						dial.dismiss();
					}
				});
				yes.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (!edit1.getText().toString().equals("")) {
							if (!edit1.getText().toString().equals(todolistmap.get((int)_pos).get("title").toString()) || (!date.getText().toString().equals(todolistmap.get((int)_pos).get("duedate").toString()) || !edit2.getText().toString().equals(todolistmap.get((int)_pos).get("description").toString()))) {
								final AlertDialog datedialog = new AlertDialog.Builder(MainActivity.this).create();
								View inflate = getLayoutInflater().inflate(R.layout.load, null);
								datedialog.setView(inflate);
								datedialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
								final LinearLayout linear2 = (LinearLayout)
								inflate.findViewById(R.id.linear2);
								tm = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												final AlertDialog doned = new AlertDialog.Builder(MainActivity.this).create();
												View inflate = getLayoutInflater().inflate(R.layout.created, null);
												doned.setView(inflate);
												doned.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
												final TextView topnote = (TextView)
												inflate.findViewById(R.id.topnote);
												final TextView button = (TextView)
												inflate.findViewById(R.id.button);
												final LinearLayout linear2 = (LinearLayout)
												inflate.findViewById(R.id.linear2);
												button.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
														this.setColor(b); 
														this.setStroke(c, d); 
														return this; 
													} }.getIns((int)8, Color.TRANSPARENT,1 ,0xFF000000));
												linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
														this.setColor(b); 
														this.setStroke(c, d); 
														return this; 
													} }.getIns((int)25, 0xFFFFFFFF,1 ,0xFFFFFFFF));
												final ImageView img = (ImageView)
												inflate.findViewById(R.id.img);
												try{
													todolistmap.get((int)_pos).put("title", edit1.getText().toString());
													todolistmap.get((int)_pos).put("description", edit2.getText().toString());
													todolistmap.get((int)_pos).put("duedate", date.getText().toString());
													Date now=new Date();
													SimpleDateFormat datepicker=new SimpleDateFormat("dd/MM/yyyy");
													SimpleDateFormat timepicker=new SimpleDateFormat("HH:mm");
													final String updateddate=datepicker.format(now);
													final String updatedtime=timepicker.format(now);
													todolistmap.get((int)_pos).put("updatedon", updateddate);
													todolistmap.get((int)_pos).put("updatedtime", updatedtime);
													FileUtil.writeFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/db.json"), new Gson().toJson(todolistmap));
													topnote.setText("Updated Successful");
													topnote.setTextColor(0xFF4CAF50);
													img.setImageResource(R.drawable.icon_done_round);
												}catch(Exception e){
													topnote.setText("Update failed!");
													topnote.setTextColor(0xFF000000);
													img.setImageResource(R.drawable.icon_error_outline_round);
												}
												button.setOnClickListener(new View.OnClickListener() {
													@Override
													public void onClick(View _view) {
														doned.dismiss();
														((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
														dial.dismiss();
													}
												});
												datedialog.dismiss();
												doned.show();
												_viewThis(_pos);
												((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
											}
										});
									}
								};
								_timer.schedule(tm, (int)(2000));
								linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
										this.setColor(b); 
										this.setStroke(c, d); 
										return this; 
									} }.getIns((int)25, 0xFFFFFFFF,1 ,0xFFFFFFFF));
								datedialog.show();
							} else {
								SketchwareUtil.showMessage(getApplicationContext(), "no changes detected! ");
							}
						} else {
							SketchwareUtil.showMessage(getApplicationContext(), "something went wrong ");
						}
					}
				});
				linear8.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						datedialog.setTitle("Update due date");
						final DatePicker dpicker = new DatePicker(MainActivity.this);
						dpicker.setMinDate(Calendar.getInstance().getTimeInMillis());
						String dateString = date.getText().toString();
						String[] parts = dateString.split("/");
						int day = Integer.parseInt(parts[0]);
						int month = Integer.parseInt(parts[1]) -1;
						int year = Integer.parseInt(parts[2]);
						
						dpicker.updateDate(year, month, day);
						calender = Calendar.getInstance(); 
						calender.set((int) 2026,(int) 11,(int) 31); 
						dpicker.setMaxDate(calender.getTimeInMillis());
						datedialog.setView(dpicker);
						
						datedialog.setPositiveButton("Set", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								int year=dpicker. getYear();
								int month= dpicker.getMonth()+1;
								int daydate=dpicker. getDayOfMonth();
								String nowdate=String.format("%02d/%02d/%04d",daydate,month,year);
								date.setText(nowdate);
							}
						});
						datedialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						datedialog.create().show();
					}
				});
			}
		});
		binding.contents.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				binding.editbt.performClick();
				return true;
			}
		});
	}
	
	
	public void _edittask(final double _pos) {
		final AlertDialog dial = new AlertDialog.Builder(MainActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.create_todo_dialog, null);
		dial.setView(inflate);
		dial.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		final LinearLayout linear2 = (LinearLayout)
		inflate.findViewById(R.id.linear2);
		final LinearLayout linear8 = (LinearLayout)
		inflate.findViewById(R.id.linear8);
		final LinearLayout linear5 = (LinearLayout)
		inflate.findViewById(R.id.linear5);
		final LinearLayout linear4 = (LinearLayout)
		inflate.findViewById(R.id.linear4);
		final TextView date = (TextView)
		inflate.findViewById(R.id.date);
		final TextView yes = (TextView)
		inflate.findViewById(R.id.yes);
		final TextView no = (TextView)
		inflate.findViewById(R.id.no);
		final TextView textview1 = (TextView)
		inflate.findViewById(R.id.textview1);
		final EditText edit1 = new EditText(MainActivity.this);
		final EditText edit2 = new EditText(MainActivity.this);
		Date now=new Date();
		SimpleDateFormat datepicker=new SimpleDateFormat("dd/MM/yyyy");
		final String selected=datepicker.format(now);
		String dueDateStr = todolistmap.get((int)_pos).get("duedate").toString();
		textview1.setText("Edit Task");
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			Date dueDate = sdf.parse(dueDateStr);
			Date currentDate = new Date();
			
			if (dueDate.before(currentDate)) {
				date.setText(datepicker.format(currentDate));
			} else {
				date.setText(dueDateStr);
			}
			
		} catch (Exception e) {
			// handle parsing error
		}
		
		edit1.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)));
		edit2.setLayoutParams(new LinearLayout.LayoutParams((int) (android.widget.LinearLayout.LayoutParams.MATCH_PARENT),(int) (android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)));
		dial.setCancelable(false);
		((LinearLayout) linear5).addView(edit2);
		edit1.setBackgroundColor(Color.TRANSPARENT);
		edit2.setBackgroundColor(Color.TRANSPARENT);
		edit2.setHint("add some description");
		edit1.setSingleLine(true);
		edit1.setHint("type you task title");
		edit1.setText(todolistmap.get((int)_pos).get("title").toString());
		edit2.setText(todolistmap.get((int)_pos).get("description").toString());
		yes.setText("Update" );
		linear4.addView(edit1);
		linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
				this.setColor(b); 
				this.setStroke(c, d); 
				return this; 
			} }.getIns((int)25, 0xFFFFFFFF,1 ,0xFFFFFFFF));
		linear8.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
				this.setColor(b); 
				this.setStroke(c, d); 
				return this; 
			} }.getIns((int)8, Color.TRANSPARENT,1 ,0xFF9E9E9E));
		linear4.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
				this.setColor(b); 
				this.setStroke(c, d); 
				return this; 
			} }.getIns((int)8, Color.TRANSPARENT,1 ,0xFF9E9E9E));
		linear5.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
				this.setColor(b); 
				this.setStroke(c, d); 
				return this; 
			} }.getIns((int)8, Color.TRANSPARENT,1 ,0xFF9E9E9E));
		dial.show();
		linear5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				edit2.requestFocus();
				SketchwareUtil.showKeyboard(getApplicationContext());
			}
		});
		no.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dial.dismiss();
			}
		});
		yes.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!edit1.getText().toString().equals("")) {
					if (!edit1.getText().toString().equals(todolistmap.get((int)_pos).get("title").toString()) || (!date.getText().toString().equals(todolistmap.get((int)_pos).get("duedate").toString()) || !edit2.getText().toString().equals(todolistmap.get((int)_pos).get("description").toString()))) {
						final AlertDialog datedialog = new AlertDialog.Builder(MainActivity.this).create();
						View inflate = getLayoutInflater().inflate(R.layout.load, null);
						datedialog.setView(inflate);
						datedialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
						final LinearLayout linear2 = (LinearLayout)
						inflate.findViewById(R.id.linear2);
						tm = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										final AlertDialog doned = new AlertDialog.Builder(MainActivity.this).create();
										View inflate = getLayoutInflater().inflate(R.layout.created, null);
										doned.setView(inflate);
										doned.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
										final TextView topnote = (TextView)
										inflate.findViewById(R.id.topnote);
										final TextView button = (TextView)
										inflate.findViewById(R.id.button);
										final LinearLayout linear2 = (LinearLayout)
										inflate.findViewById(R.id.linear2);
										button.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
												this.setColor(b); 
												this.setStroke(c, d); 
												return this; 
											} }.getIns((int)8, Color.TRANSPARENT,1 ,0xFF000000));
										linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
												this.setColor(b); 
												this.setStroke(c, d); 
												return this; 
											} }.getIns((int)25, 0xFFFFFFFF,1 ,0xFFFFFFFF));
										final ImageView img = (ImageView)
										inflate.findViewById(R.id.img);
										try{
											todolistmap.get((int)_pos).put("title", edit1.getText().toString());
											todolistmap.get((int)_pos).put("description", edit2.getText().toString());
											todolistmap.get((int)_pos).put("duedate", date.getText().toString());
											Date now=new Date();
											SimpleDateFormat datepicker=new SimpleDateFormat("dd/MM/yyyy");
											SimpleDateFormat timepicker=new SimpleDateFormat("HH:mm");
											final String updateddate=datepicker.format(now);
											final String updatedtime=timepicker.format(now);
											todolistmap.get((int)_pos).put("updatedon", updateddate);
											todolistmap.get((int)_pos).put("updatedtime", updatedtime);
											FileUtil.writeFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/db.json"), new Gson().toJson(todolistmap));
											topnote.setText("Updated Successful");
											topnote.setTextColor(0xFF4CAF50);
											img.setImageResource(R.drawable.icon_done_round);
										}catch(Exception e){
											topnote.setText("Update failed!");
											topnote.setTextColor(0xFF000000);
											img.setImageResource(R.drawable.icon_error_outline_round);
										}
										button.setOnClickListener(new View.OnClickListener() {
											@Override
											public void onClick(View _view) {
												doned.dismiss();
												_check();
												((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
												dial.dismiss();
											}
										});
										datedialog.dismiss();
										doned.show();
										((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
									}
								});
							}
						};
						_timer.schedule(tm, (int)(2000));
						linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
								this.setColor(b); 
								this.setStroke(c, d); 
								return this; 
							} }.getIns((int)25, 0xFFFFFFFF,1 ,0xFFFFFFFF));
						datedialog.show();
					} else {
						SketchwareUtil.showMessage(getApplicationContext(), "no changes detected! ");
					}
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), "something went wrong ");
				}
			}
		});
		linear8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				datedialog.setTitle("Update due date");
				final DatePicker dpicker = new DatePicker(MainActivity.this);
				dpicker.setMinDate(Calendar.getInstance().getTimeInMillis());
				String dateString = date.getText().toString();
				String[] parts = dateString.split("/");
				int day = Integer.parseInt(parts[0]);
				int month = Integer.parseInt(parts[1]) -1;
				int year = Integer.parseInt(parts[2]);
				
				dpicker.updateDate(year, month, day);
				calender = Calendar.getInstance(); 
				calender.set((int) 2026,(int) 11,(int) 31); 
				dpicker.setMaxDate(calender.getTimeInMillis());
				datedialog.setView(dpicker);
				
				datedialog.setPositiveButton("Set", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						int year=dpicker. getYear();
						int month= dpicker.getMonth()+1;
						int daydate=dpicker. getDayOfMonth();
						String nowdate=String.format("%02d/%02d/%04d",daydate,month,year);
						date.setText(nowdate);
					}
				});
				datedialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				datedialog.create().show();
			}
		});
	}
	
	
	public void _abouttask(final double _pos) {
		final AlertDialog dial = new AlertDialog.Builder(MainActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.infobox, null);
		dial.setView(inflate);
		dial.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		final TextView textview2 = (TextView)
		inflate.findViewById(R.id.textview2);
		final TextView textview3 = (TextView)
		inflate.findViewById(R.id.textview3);
		final LinearLayout linear2 = (LinearLayout)
		inflate.findViewById(R.id.linear2);
		dial.setCancelable(false);
		textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dial.dismiss();
			}
		});
		linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
				this.setColor(b); 
				this.setStroke(c, d); 
				return this; 
			} }.getIns((int)25, 0xFFFFFFFF,1 ,0xFFFFFFFF));
		textview3.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
				this.setColor(b); 
				this.setStroke(c, d); 
				return this; 
			} }.getIns((int)5, Color.TRANSPARENT,1 ,0xFF000000));
		textview2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
				this.setColor(b); 
				this.setStroke(c, d); 
				return this; 
			} }.getIns((int)8, 0xFFF5F5F5,1 ,0xFFF5F5F5));
		textview2.setText("Task Details:\nTask created on: ".concat(todolistmap.get((int)_pos).get("created").toString().concat("\nTask Due : ".concat(todolistmap.get((int)_pos).get("duedate").toString().concat("\n".concat(updatedoninfo.concat("\n".concat(updatedtimeinfo))))))));
		dial.setOnKeyListener(new DialogInterface.OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dial, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_BACK) {
					dial.dismiss();
					return true;
				}
				return false;
			}
		});
		dial.show();
	}
	
	
	public void _help() {
		final AlertDialog dial = new AlertDialog.Builder(MainActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.helpbox, null);
		dial.setView(inflate);
		dial.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		final TextView textview2 = (TextView)
		inflate.findViewById(R.id.textview2);
		final TextView textview3 = (TextView)
		inflate.findViewById(R.id.textview3);
		final LinearLayout linear2 = (LinearLayout)
		inflate.findViewById(R.id.linear2);
		textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dial.dismiss();
			}
		});
		linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
				this.setColor(b); 
				this.setStroke(c, d); 
				return this; 
			} }.getIns((int)15, 0xFFFFFFFF,1 ,0xFFFFFFFF));
		textview3.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
				this.setColor(b); 
				this.setStroke(c, d); 
				return this; 
			} }.getIns((int)5, Color.TRANSPARENT,1 ,0xFF000000));
		textview2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
				this.setColor(b); 
				this.setStroke(c, d); 
				return this; 
			} }.getIns((int)8, 0xFFF5F5F5,1 ,0xFFF5F5F5));
		dial.setOnKeyListener(new DialogInterface.OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dial, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_BACK) {
					dial.dismiss();
					return true;
				}
				return false;
			}
		});
		dial.setCancelable(true);
		dial.show();
	}
	
	
	public void _deletetask(final double _pos) {
		final AlertDialog dial = new AlertDialog.Builder(MainActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.view_item, null);
		dial.setView(inflate);
		dial.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		final TextView info = (TextView)
		inflate.findViewById(R.id.info);
		final TextView yes = (TextView)
		inflate.findViewById(R.id.yes);
		final TextView no = (TextView)
		inflate.findViewById(R.id.no);
		final LinearLayout linear2 = (LinearLayout)
		inflate.findViewById(R.id.linear2);
		linear2.setBackground(new android.graphics.drawable.GradientDrawable() { public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); 
				this.setColor(b); 
				this.setStroke(c, d); 
				return this; 
			} }.getIns((int)20, 0xFFFFFFFF,1 ,0xFFFFFFFF));
		info.setText("are you sure want to delete "+ todolistmap.get((int)_pos).get("title").toString() +" Task?");
		dial.setCancelable(false);
		dial.setOnKeyListener(new DialogInterface.OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dial, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_BACK) {
					dial.dismiss();
					return true;
				}
				return false;
			}
		});
		no.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dial.dismiss();
			}
		});
		yes.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				todolistmap.remove((int)(_pos));
				FileUtil.writeFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/db.json"), new Gson().toJson(todolistmap));
				_updatelist();
				if (binding.linear4.getVisibility() == View.VISIBLE) {
					binding.linear4.setVisibility(View.GONE);
					binding.linear1.setVisibility(View.VISIBLE);
				}
				_listItemsload();
				dial.dismiss();
			}
		});
		dial.show();
	}
	
	
	public void _search(final String _searchThis) {
		searched.clear();
		history.clear();
		if (!_searchThis.equals("")) {
			searchindex = 0;
			for(int _repeat16 = 0; _repeat16 < (int)(todolistmap.size()); _repeat16++) {
				if (todolistmap.get((int)searchindex).get("title").toString().toLowerCase().contains(_searchThis.toLowerCase())) {
					searched.add(todolistmap.get((int)(searchindex)));
				}
				searchindex++;
			}
			for(int _repeat50 = 0; _repeat50 < (int)(historymap.size()); _repeat50++) {
				if (historymap.get((int)historyindex).get("historyname").toString().toLowerCase().contains(_searchThis.toLowerCase())) {
					history.add(historymap.get((int)(historyindex)));
				}
				historyindex++;
			}
			if (searched.size() > 0) {
				binding.noresults.setVisibility(View.GONE);
			} else {
				binding.noresults.setVisibility(View.VISIBLE);
			}
		} else {
			history.addAll(historymap);
			binding.noresults.setVisibility(View.GONE);
		}
		((BaseAdapter)binding.listview3.getAdapter()).notifyDataSetChanged();
		((BaseAdapter)binding.listview2.getAdapter()).notifyDataSetChanged();
	}
	
	
	public void _check() {
		for (Map<String, Object> task : todolistmap) {
			if (task.containsKey("duedate") && task.get("duedate") != null) {
				String dueDateStr = task.get("duedate").toString();
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				try {
					Date dueDate = sdf.parse(dueDateStr);
					Date currentDate = new Date();
					long todayEnd = currentDate.getTime();
					if ((dueDate.getTime() + (24 * 60 * 60 * 1000) ) < todayEnd) {
						task.put("complete", true);
					} else {
						task.put("complete", false);
					}
				} catch (Exception e) {
					// handle parsing error
				}
			}
		}
		
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			ItemsBinding binding = ItemsBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.title.setText(todolistmap.get((int)_position).get("title").toString());
			binding.description.setText("Task created:".concat(todolistmap.get((int)_position).get("created").toString()));
			binding.duedate.setText("Task Due: ".concat(todolistmap.get((int)_position).get("duedate").toString()));
			binding.linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFFFFFFFF));
			binding.linear1.setOnLongClickListener(new View.OnLongClickListener(){
				@Override
				public boolean onLongClick(View _longClickedView){
					_deletetask(_position);
					return false;
				}
			});
			binding.imageview2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					PopupMenu menus = new PopupMenu(getApplicationContext(), _view);
					
					menus.getMenu().add("View Task");
					menus.getMenu().add("Task info");
					menus.getMenu().add("Edit Task");
					if (todolistmap.get((int)_position).get("complete").equals(true)) {
						menus.getMenu().add("Restart Task");
					}
					menus.getMenu().add("Delete Task");
					menus.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener(){
						@Override
						public boolean onMenuItemClick(MenuItem menuItem){
							if (menuItem.getTitle().toString().equals("View Task")) {
								_viewThis(_position);
							}
							if (menuItem.getTitle().toString().equals("Task info")) {
								_abouttask(_position);
							}
							if (menuItem.getTitle().toString().equals("Edit Task")) {
								_edittask(_position);
							}
							if (menuItem.getTitle().toString().equals("Delete Task")) {
								_deletetask(_position);
							}
							if (menuItem.getTitle().toString().equals("Restart Task")) {
								_edittask(_position);
							}
							return true;
						}
					});
					menus.show();
				}
			});
			if (todolistmap.get((int)_position).get("complete").equals(true)) {
				binding.complete.setImageResource(R.drawable.icon_check_box_baseline);
				binding.title.setTextColor(0xFF9E9E9E);
				binding.description.setTextColor(0xFF9E9E9E);
				binding.duedate.setTextColor(0xFF9E9E9E);
				binding.textview1.setTextColor(0xFF9E9E9E);
				binding.reminderstatus.setTextColor(0xFF9E9E9E);
				binding.textview1.setText("Completed");
				binding.reminderdulation.setTextColor(0xFF9E9E9E);
			} else {
				binding.textview1.setText("Override");
				binding.complete.setImageResource(R.drawable.icon_check_box_outline_blank_round);
				binding.title.setTextColor(0xFF4CAF50);
				binding.description.setTextColor(0xFF4CAF50);
				binding.duedate.setTextColor(0xFF4CAF50);
				binding.textview1.setTextColor(0xFF4CAF50);
				binding.reminderstatus.setTextColor(0xFF4CAF50);
				binding.reminderdulation.setTextColor(0xFF4CAF50);
			}
			binding.linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_viewThis(_position);
				}
			});
			if (!todolistmap.get((int)_position).get("startat").toString().equals("")) {
				binding.reminderstatus.setText("Task status:".concat("not active"));
				binding.reminderdulation.setText("Task duration:\n    From: ".concat(todolistmap.get((int)_position).get("startat").toString().concat("\n    To: ".concat(todolistmap.get((int)_position).get("endat").toString()))));
				binding.reminderstatus.setVisibility(View.VISIBLE);
				binding.reminderdulation.setVisibility(View.VISIBLE);
			} else {
				binding.reminderstatus.setVisibility(View.GONE);
				binding.reminderdulation.setVisibility(View.GONE);
			}
			
			return _view;
		}
	}
	
	public class Listview2Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			HistoryitemBinding binding = HistoryitemBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(history.get((int)_position).get("historyname").toString());
			binding.linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_search(history.get((int)_position).get("historyname").toString());
				}
			});
			
			return _view;
		}
	}
	
	public class Listview3Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview3Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			ItemsBinding binding = ItemsBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.title.setText(searched.get((int)_position).get("title").toString());
			binding.description.setText("Task created:".concat(searched.get((int)_position).get("created").toString()));
			binding.duedate.setText("Task Due: ".concat(searched.get((int)_position).get("duedate").toString()));
			binding.linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFFFFFFFF));
			if (searched.get((int)_position).get("complete").equals(true)) {
				binding.complete.setImageResource(R.drawable.icon_check_box_baseline);
				binding.title.setTextColor(0xFF9E9E9E);
				binding.description.setTextColor(0xFF9E9E9E);
				binding.duedate.setTextColor(0xFF9E9E9E);
				binding.textview1.setTextColor(0xFF9E9E9E);
				binding.reminderstatus.setTextColor(0xFF9E9E9E);
				binding.reminderdulation.setTextColor(0xFF9E9E9E);
			} else {
				binding.complete.setImageResource(R.drawable.icon_check_box_outline_blank_round);
				binding.title.setTextColor(0xFF4CAF50);
				binding.description.setTextColor(0xFF4CAF50);
				binding.duedate.setTextColor(0xFF4CAF50);
				binding.textview1.setTextColor(0xFF4CAF50);
				binding.reminderstatus.setTextColor(0xFF4CAF50);
				binding.reminderdulation.setTextColor(0xFF4CAF50);
			}
			binding.linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					searchindex = 0;
					for(int _repeat89 = 0; _repeat89 < (int)(todolistmap.size()); _repeat89++) {
						if (todolistmap.get((int)searchindex).get("title").toString().equals(searched.get((int)_position).get("title").toString())) {
							historyindex = searchindex;
						}
						searchindex++;
					}
					_viewThis(historyindex);
				}
			});
			
			return _view;
		}
	}
}